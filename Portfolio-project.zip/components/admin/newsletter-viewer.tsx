"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2, Users, Download } from "lucide-react"
import { NewsletterDB } from "@/lib/db/storage"
import type { Newsletter } from "@/lib/types"

export function NewsletterViewer() {
  const [subscribers, setSubscribers] = useState<Newsletter[]>([])

  useEffect(() => {
    loadSubscribers()

    const interval = setInterval(loadSubscribers, 2000)

    return () => {
      clearInterval(interval)
    }
  }, [])

  const loadSubscribers = () => {
    const allSubscribers = NewsletterDB.getAll()
    // Sort by timestamp descending (newest first)
    allSubscribers.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    setSubscribers(allSubscribers)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to remove this subscriber?")) {
      NewsletterDB.delete(id)
      loadSubscribers()
    }
  }

  const handleExport = () => {
    const emails = subscribers.map((s) => s.email).join("\n")
    const blob = new Blob([emails], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `newsletter-subscribers-${new Date().toISOString().split("T")[0]}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-2xl font-bold text-slate-900">{subscribers.length}</h3>
              <p className="text-slate-600">Total Subscribers</p>
            </div>
            {subscribers.length > 0 && (
              <Button onClick={handleExport}>
                <Download className="h-4 w-4 mr-2" />
                Export Emails
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {subscribers.map((subscriber) => (
          <Card key={subscriber.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-slate-100 flex items-center justify-center">
                    <Users className="h-5 w-5 text-slate-600" />
                  </div>
                  <div>
                    <p className="font-medium text-slate-900">{subscriber.email}</p>
                    <p className="text-xs text-slate-500">{formatDate(subscriber.timestamp)}</p>
                  </div>
                </div>
                <Button size="sm" variant="outline" onClick={() => handleDelete(subscriber.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {subscribers.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Users className="h-12 w-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">No newsletter subscribers yet.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
