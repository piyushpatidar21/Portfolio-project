import { AuthGuard } from "@/components/admin/auth-guard"
import { DashboardLayout } from "@/components/admin/dashboard-layout"
import { ContactsViewer } from "@/components/admin/contacts-viewer"

export default function ContactsPage() {
  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Contact Messages</h1>
          <p className="text-slate-600">View and manage contact form submissions</p>
        </div>
        <ContactsViewer />
      </DashboardLayout>
    </AuthGuard>
  )
}
