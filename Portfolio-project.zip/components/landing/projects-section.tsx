"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink } from "lucide-react"
import { useState, useEffect } from "react"
import { ProjectsDB } from "@/lib/db/storage"
import type { Project } from "@/lib/types"

export function ProjectsSection() {
  const [projects, setProjects] = useState<Project[]>([])

  useEffect(() => {
    const loadProjects = () => {
      let allProjects = ProjectsDB.getAll()

      if (allProjects.length === 0) {
        const mockProjects: Omit<Project, "id">[] = [
          {
            title: "E-Commerce Platform",
            description: "A modern e-commerce solution with seamless payment integration and inventory management",
            image: "/modern-ecommerce-website.png",
            link: "https://example.com",
          },
          {
            title: "Healthcare Dashboard",
            description: "Comprehensive patient management system with real-time analytics and reporting",
            image: "/healthcare-dashboard.png",
            link: "https://example.com",
          },
          {
            title: "Financial Analytics App",
            description: "Advanced financial tracking and analytics platform for businesses",
            image: "/financial-analytics-dashboard.png",
            link: "https://example.com",
          },
        ]
        mockProjects.forEach((project) => ProjectsDB.create(project))
        allProjects = ProjectsDB.getAll()
      }

      setProjects(allProjects)
    }

    loadProjects()

    // Auto-refresh every 2 seconds to show admin updates
    const interval = setInterval(loadProjects, 2000)

    return () => {
      clearInterval(interval)
    }
  }, [])

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">Our Projects</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Explore our portfolio of successful projects delivered to satisfied clients
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <Card key={project.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <img src={project.image || "/placeholder.svg"} alt={project.title} className="w-full h-48 object-cover" />
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold text-slate-900 mb-2">{project.title}</h3>
                <p className="text-slate-600 mb-4">{project.description}</p>
                <Button variant="outline" className="w-full bg-transparent" asChild>
                  <a href={project.link} target="_blank" rel="noopener noreferrer">
                    View Project
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
