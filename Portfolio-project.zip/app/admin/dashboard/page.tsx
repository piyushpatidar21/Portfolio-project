import { AuthGuard } from "@/components/admin/auth-guard"
import { DashboardLayout } from "@/components/admin/dashboard-layout"
import { DashboardStats } from "@/components/admin/dashboard-stats"

export default function DashboardPage() {
  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Dashboard</h1>
          <p className="text-slate-600">Welcome to your admin panel</p>
        </div>
        <DashboardStats />
      </DashboardLayout>
    </AuthGuard>
  )
}
