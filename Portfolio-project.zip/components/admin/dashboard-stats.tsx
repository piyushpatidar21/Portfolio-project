"use client"

import { Card, CardContent } from "@/components/ui/card"
import { FolderKanban, MessageSquare, Mail, Users } from "lucide-react"
import { useEffect, useState } from "react"
import { getDashboardStats } from "@/lib/actions/stats"
import type { DashboardStats as Stats } from "@/lib/types"

export function DashboardStats() {
  const [stats, setStats] = useState<Stats>({
    totalProjects: 0,
    totalTestimonials: 0,
    totalContacts: 0,
    totalSubscribers: 0,
  })

  useEffect(() => {
    const loadStats = () => {
      setStats(getDashboardStats())
    }

    loadStats()

    // Auto-refresh every 2 seconds
    const interval = setInterval(loadStats, 2000)

    return () => {
      clearInterval(interval)
    }
  }, [])

  const statCards = [
    {
      title: "Total Projects",
      value: stats.totalProjects,
      icon: FolderKanban,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "Testimonials",
      value: stats.totalTestimonials,
      icon: MessageSquare,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Contact Messages",
      value: stats.totalContacts,
      icon: Mail,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
    },
    {
      title: "Newsletter Subscribers",
      value: stats.totalSubscribers,
      icon: Users,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {statCards.map((stat) => (
        <Card key={stat.title}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-slate-600 mb-1">{stat.title}</p>
                <p className="text-3xl font-bold text-slate-900">{stat.value}</p>
              </div>
              <div className={`h-12 w-12 rounded-lg ${stat.bgColor} flex items-center justify-center`}>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
