import type { Project, Testimonial, Contact, Newsletter } from "@/lib/types"

// Storage keys
const STORAGE_KEYS = {
  PROJECTS: "flipr_projects",
  TESTIMONIALS: "flipr_testimonials",
  CONTACTS: "flipr_contacts",
  NEWSLETTER: "flipr_newsletter",
  AUTH: "flipr_auth",
} as const

// Generic storage operations
class Storage {
  static get<T>(key: string): T[] {
    if (typeof window === "undefined") return []
    const data = localStorage.getItem(key)
    return data ? JSON.parse(data) : []
  }

  static set<T>(key: string, data: T[]): void {
    if (typeof window === "undefined") return
    localStorage.setItem(key, JSON.stringify(data))
  }

  static clear(key: string): void {
    if (typeof window === "undefined") return
    localStorage.removeItem(key)
  }
}

// Projects operations
export const ProjectsDB = {
  getAll: (): Project[] => Storage.get<Project>(STORAGE_KEYS.PROJECTS),

  create: (project: Omit<Project, "id">): Project => {
    const newProject: Project = {
      ...project,
      id: Date.now().toString(),
    }
    const projects = ProjectsDB.getAll()
    Storage.set(STORAGE_KEYS.PROJECTS, [...projects, newProject])
    return newProject
  },

  update: (id: string, data: Omit<Project, "id">): Project | null => {
    const projects = ProjectsDB.getAll()
    const index = projects.findIndex((p) => p.id === id)
    if (index === -1) return null

    const updated = { ...data, id }
    projects[index] = updated
    Storage.set(STORAGE_KEYS.PROJECTS, projects)
    return updated
  },

  delete: (id: string): boolean => {
    const projects = ProjectsDB.getAll()
    const filtered = projects.filter((p) => p.id !== id)
    if (filtered.length === projects.length) return false

    Storage.set(STORAGE_KEYS.PROJECTS, filtered)
    return true
  },
}

// Testimonials operations
export const TestimonialsDB = {
  getAll: (): Testimonial[] => Storage.get<Testimonial>(STORAGE_KEYS.TESTIMONIALS),

  create: (testimonial: Omit<Testimonial, "id">): Testimonial => {
    const newTestimonial: Testimonial = {
      ...testimonial,
      id: Date.now().toString(),
    }
    const testimonials = TestimonialsDB.getAll()
    Storage.set(STORAGE_KEYS.TESTIMONIALS, [...testimonials, newTestimonial])
    return newTestimonial
  },

  update: (id: string, data: Omit<Testimonial, "id">): Testimonial | null => {
    const testimonials = TestimonialsDB.getAll()
    const index = testimonials.findIndex((t) => t.id === id)
    if (index === -1) return null

    const updated = { ...data, id }
    testimonials[index] = updated
    Storage.set(STORAGE_KEYS.TESTIMONIALS, testimonials)
    return updated
  },

  delete: (id: string): boolean => {
    const testimonials = TestimonialsDB.getAll()
    const filtered = testimonials.filter((t) => t.id !== id)
    if (filtered.length === testimonials.length) return false

    Storage.set(STORAGE_KEYS.TESTIMONIALS, filtered)
    return true
  },
}

// Contacts operations
export const ContactsDB = {
  getAll: (): Contact[] => Storage.get<Contact>(STORAGE_KEYS.CONTACTS),

  create: (contact: Omit<Contact, "id" | "timestamp">): Contact => {
    const newContact: Contact = {
      ...contact,
      id: Date.now().toString(),
      timestamp: new Date().toISOString(),
    }
    const contacts = ContactsDB.getAll()
    Storage.set(STORAGE_KEYS.CONTACTS, [...contacts, newContact])
    return newContact
  },

  delete: (id: string): boolean => {
    const contacts = ContactsDB.getAll()
    const filtered = contacts.filter((c) => c.id !== id)
    if (filtered.length === contacts.length) return false

    Storage.set(STORAGE_KEYS.CONTACTS, filtered)
    return true
  },
}

// Newsletter operations
export const NewsletterDB = {
  getAll: (): Newsletter[] => Storage.get<Newsletter>(STORAGE_KEYS.NEWSLETTER),

  create: (email: string): Newsletter => {
    const newSubscriber: Newsletter = {
      id: Date.now().toString(),
      email,
      timestamp: new Date().toISOString(),
    }
    const subscribers = NewsletterDB.getAll()

    // Check if email already exists
    if (subscribers.some((s) => s.email === email)) {
      throw new Error("Email already subscribed")
    }

    Storage.set(STORAGE_KEYS.NEWSLETTER, [...subscribers, newSubscriber])
    return newSubscriber
  },

  delete: (id: string): boolean => {
    const subscribers = NewsletterDB.getAll()
    const filtered = subscribers.filter((s) => s.id !== id)
    if (filtered.length === subscribers.length) return false

    Storage.set(STORAGE_KEYS.NEWSLETTER, filtered)
    return true
  },
}

// Authentication
export const AuthDB = {
  login: (username: string, password: string): boolean => {
    // Simple authentication check
    if (username === "admin" && password === "admin123") {
      if (typeof window !== "undefined") {
        localStorage.setItem(STORAGE_KEYS.AUTH, "authenticated")
      }
      return true
    }
    return false
  },

  logout: (): void => {
    Storage.clear(STORAGE_KEYS.AUTH)
  },

  isAuthenticated: (): boolean => {
    if (typeof window === "undefined") return false
    return localStorage.getItem(STORAGE_KEYS.AUTH) === "authenticated"
  },
}
