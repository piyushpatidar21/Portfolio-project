export interface Project {
  id: string
  title: string
  description: string
  image: string
  link: string
}

export interface Testimonial {
  id: string
  name: string
  designation: string
  description: string
  image: string
}

export interface Contact {
  id: string
  fullName: string
  email: string
  mobile: string
  city: string
  timestamp: string
}

export interface Newsletter {
  id: string
  email: string
  timestamp: string
}

export interface DashboardStats {
  totalProjects: number
  totalTestimonials: number
  totalContacts: number
  totalSubscribers: number
}
