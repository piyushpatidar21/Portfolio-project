"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Trash2, Mail, Phone, MapPin, User } from "lucide-react"
import { ContactsDB } from "@/lib/db/storage"
import type { Contact } from "@/lib/types"

export function ContactsViewer() {
  const [contacts, setContacts] = useState<Contact[]>([])

  useEffect(() => {
    loadContacts()

    const interval = setInterval(loadContacts, 2000)

    return () => {
      clearInterval(interval)
    }
  }, [])

  const loadContacts = () => {
    const allContacts = ContactsDB.getAll()
    // Sort by timestamp descending (newest first)
    allContacts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    setContacts(allContacts)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this message?")) {
      ContactsDB.delete(id)
      loadContacts()
    }
  }

  const formatDate = (timestamp: string) => {
    return new Date(timestamp).toLocaleDateString("en-US", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  return (
    <div className="space-y-4">
      {contacts.map((contact) => (
        <Card key={contact.id}>
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-slate-100 flex items-center justify-center">
                  <User className="h-6 w-6 text-slate-600" />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900">{contact.fullName}</h3>
                  <p className="text-xs text-slate-500 mt-1">{formatDate(contact.timestamp)}</p>
                </div>
              </div>
              <Button size="sm" variant="outline" onClick={() => handleDelete(contact.id)}>
                <Trash2 className="h-4 w-4 mr-1" />
                Delete
              </Button>
            </div>
            <div className="bg-slate-50 p-4 rounded-lg space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <Mail className="h-4 w-4 text-slate-600" />
                <span className="font-medium text-slate-900">Email:</span>
                <span className="text-slate-700">{contact.email}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-slate-600" />
                <span className="font-medium text-slate-900">Mobile:</span>
                <span className="text-slate-700">{contact.mobile}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-slate-600" />
                <span className="font-medium text-slate-900">City:</span>
                <span className="text-slate-700">{contact.city}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}

      {contacts.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center">
            <Mail className="h-12 w-12 text-slate-400 mx-auto mb-4" />
            <p className="text-slate-600">No contact messages yet.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
