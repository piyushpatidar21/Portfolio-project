"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { Plus, Pencil, Trash2, X, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { TestimonialsDB } from "@/lib/db/storage"
import { cropImage } from "@/lib/utils/image-cropper"
import type { Testimonial } from "@/lib/types"

interface FormData {
  name: string
  designation: string
  description: string
  image: string
}

export function TestimonialsManager() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])
  const [isAdding, setIsAdding] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState<FormData>({
    name: "",
    designation: "",
    image: "",
    description: "",
  })
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    loadTestimonials()
  }, [])

  const loadTestimonials = () => {
    setTestimonials(TestimonialsDB.getAll())
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    try {
      const croppedImage = await cropImage(file)
      setFormData({ ...formData, image: croppedImage })

      toast({
        title: "Image uploaded",
        description: "Image has been cropped to 450x350",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to process image",
        variant: "destructive",
      })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingId) {
      TestimonialsDB.update(editingId, formData)
      setEditingId(null)
      toast({
        title: "Client updated",
        description: "Client testimonial has been updated successfully",
      })
    } else {
      TestimonialsDB.create(formData)
      setIsAdding(false)
      toast({
        title: "Client added",
        description: "New client testimonial has been added successfully",
      })
    }

    setFormData({ name: "", designation: "", image: "", description: "" })
    loadTestimonials()
  }

  const handleEdit = (testimonial: Testimonial) => {
    setFormData({
      name: testimonial.name,
      designation: testimonial.designation,
      image: testimonial.image,
      description: testimonial.description,
    })
    setEditingId(testimonial.id)
    setIsAdding(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this testimonial?")) {
      TestimonialsDB.delete(id)
      loadTestimonials()
      toast({
        title: "Client deleted",
        description: "Client testimonial has been deleted successfully",
      })
    }
  }

  const handleCancel = () => {
    setIsAdding(false)
    setEditingId(null)
    setFormData({ name: "", designation: "", image: "", description: "" })
  }

  return (
    <div className="space-y-6">
      {!isAdding && !editingId && (
        <Button onClick={() => setIsAdding(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add New Client
        </Button>
      )}

      {(isAdding || editingId) && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-900">{editingId ? "Edit Client" : "Add New Client"}</h3>
              <Button variant="ghost" size="icon" onClick={handleCancel}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-900 mb-2">
                  Client Name
                </label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  placeholder="Client name"
                />
              </div>
              <div>
                <label htmlFor="designation" className="block text-sm font-medium text-slate-900 mb-2">
                  Client Designation
                </label>
                <Input
                  id="designation"
                  value={formData.designation}
                  onChange={(e) => setFormData({ ...formData, designation: e.target.value })}
                  required
                  placeholder="e.g., CEO, Web Developer, Designer"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">Client Image</label>
                <div className="flex gap-2">
                  <Input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Image (450x350)
                  </Button>
                  <Input
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="Or paste image URL"
                    className="flex-1"
                  />
                </div>
                {formData.image && (
                  <img
                    src={formData.image || "/placeholder.svg"}
                    alt="Preview"
                    className="mt-2 w-32 h-32 rounded-full object-cover"
                  />
                )}
              </div>
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-900 mb-2">
                  Client Description
                </label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  placeholder="Client testimonial or description..."
                  rows={4}
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit">{editingId ? "Update Client" : "Add Client"}</Button>
                <Button type="button" variant="outline" onClick={handleCancel}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {testimonials.map((testimonial) => (
          <Card key={testimonial.id}>
            <CardContent className="p-6">
              <div className="flex items-center gap-4 mb-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={testimonial.image || "/placeholder.svg"} alt={testimonial.name} />
                  <AvatarFallback>
                    {testimonial.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="font-bold text-slate-900">{testimonial.name}</h3>
                  <p className="text-sm text-slate-600">{testimonial.designation}</p>
                </div>
              </div>
              <p className="text-slate-700 mb-4 italic">"{testimonial.description}"</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => handleEdit(testimonial)}>
                  <Pencil className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleDelete(testimonial.id)}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {testimonials.length === 0 && !isAdding && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-600">No clients yet. Add your first client testimonial to get started.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
