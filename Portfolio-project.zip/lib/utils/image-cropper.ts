export interface CropDimensions {
  width: number
  height: number
}

export const DEFAULT_CROP_SIZE: CropDimensions = {
  width: 450,
  height: 350,
}

export async function cropImage(file: File, dimensions: CropDimensions = DEFAULT_CROP_SIZE): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("File is not an image"))
      return
    }

    const reader = new FileReader()

    reader.onload = (event) => {
      const img = new Image()

      img.onload = () => {
        const canvas = document.createElement("canvas")
        canvas.width = dimensions.width
        canvas.height = dimensions.height

        const ctx = canvas.getContext("2d")
        if (!ctx) {
          reject(new Error("Could not get canvas context"))
          return
        }

        // Calculate crop dimensions to maintain aspect ratio
        const sourceAspect = img.width / img.height
        const targetAspect = dimensions.width / dimensions.height

        let sourceWidth = img.width
        let sourceHeight = img.height
        let sourceX = 0
        let sourceY = 0

        if (sourceAspect > targetAspect) {
          // Image is wider, crop width
          sourceWidth = img.height * targetAspect
          sourceX = (img.width - sourceWidth) / 2
        } else {
          // Image is taller, crop height
          sourceHeight = img.width / targetAspect
          sourceY = (img.height - sourceHeight) / 2
        }

        // Draw cropped image
        ctx.drawImage(img, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, dimensions.width, dimensions.height)

        // Convert to base64
        const croppedImage = canvas.toDataURL("image/jpeg", 0.9)
        resolve(croppedImage)
      }

      img.onerror = () => reject(new Error("Failed to load image"))
      img.src = event.target?.result as string
    }

    reader.onerror = () => reject(new Error("Failed to read file"))
    reader.readAsDataURL(file)
  })
}
