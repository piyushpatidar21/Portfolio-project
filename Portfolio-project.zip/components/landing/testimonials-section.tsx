"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"
import { useState, useEffect } from "react"
import { TestimonialsDB } from "@/lib/db/storage"
import type { Testimonial } from "@/lib/types"

export function TestimonialsSection() {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([])

  useEffect(() => {
    const loadTestimonials = () => {
      let allTestimonials = TestimonialsDB.getAll()

      if (allTestimonials.length === 0) {
        const mockTestimonials: Omit<Testimonial, "id">[] = [
          {
            name: "Sarah Johnson",
            designation: "CEO",
            image: "/professional-woman-portrait.png",
            description:
              "Outstanding work! The team delivered beyond our expectations and the project was completed on time.",
          },
          {
            name: "Michael Chen",
            designation: "Product Manager",
            image: "/professional-man-portrait.png",
            description: "Professional, creative, and reliable. They transformed our vision into a stunning reality.",
          },
          {
            name: "Emily Rodriguez",
            designation: "Founder",
            image: "/professional-businesswoman-headshot.png",
            description: "Exceptional quality and attention to detail. Highly recommend for any digital project.",
          },
        ]
        mockTestimonials.forEach((testimonial) => TestimonialsDB.create(testimonial))
        allTestimonials = TestimonialsDB.getAll()
      }

      setTestimonials(allTestimonials)
    }

    loadTestimonials()

    // Auto-refresh every 2 seconds to show admin updates
    const interval = setInterval(loadTestimonials, 2000)

    return () => {
      clearInterval(interval)
    }
  }, [])

  return (
    <section id="testimonials" className="py-20 bg-slate-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">Happy Clients</h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Don't just take our word for it - hear what our clients have to say
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => (
            <Card key={testimonial.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center gap-4 mb-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={testimonial.image || "/placeholder.svg"} alt={testimonial.name} />
                    <AvatarFallback>
                      {testimonial.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-bold text-slate-900">{testimonial.name}</h3>
                    <p className="text-sm text-slate-600">{testimonial.designation}</p>
                  </div>
                </div>
                <p className="text-slate-700 italic">"{testimonial.description}"</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
