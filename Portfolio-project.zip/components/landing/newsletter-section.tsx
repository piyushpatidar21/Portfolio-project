"use client"

import type React from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"
import { useToast } from "@/hooks/use-toast"
import { NewsletterDB } from "@/lib/db/storage"

export function NewsletterSection() {
  const [email, setEmail] = useState("")
  const [subscribed, setSubscribed] = useState(false)
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    try {
      NewsletterDB.create(email)

      toast({
        title: "Successfully subscribed!",
        description: "Thank you for subscribing to our newsletter.",
      })

      setSubscribed(true)
      setEmail("")

      setTimeout(() => setSubscribed(false), 3000)
    } catch (error) {
      toast({
        title: "Already subscribed",
        description: "This email is already subscribed to our newsletter.",
        variant: "destructive",
      })
    }
  }

  return (
    <section className="py-20 bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">Stay Updated</h2>
          <p className="text-lg text-slate-300 mb-8">
            Subscribe to our newsletter for the latest updates, insights, and exclusive content
          </p>
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              placeholder="Enter your email"
              className="bg-white"
            />
            <Button type="submit" size="lg" className="whitespace-nowrap">
              {subscribed ? "Subscribed!" : "Subscribe"}
            </Button>
          </form>
        </div>
      </div>
    </section>
  )
}
