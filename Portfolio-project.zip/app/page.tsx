import { HeroSection } from "@/components/landing/hero-section"
import { ProjectsSection } from "@/components/landing/projects-section"
import { TestimonialsSection } from "@/components/landing/testimonials-section"
import { ContactSection } from "@/components/landing/contact-section"
import { NewsletterSection } from "@/components/landing/newsletter-section"
import { Footer } from "@/components/landing/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <HeroSection />
      <ProjectsSection />
      <TestimonialsSection />
      <ContactSection />
      <NewsletterSection />
      <Footer />
    </main>
  )
}
