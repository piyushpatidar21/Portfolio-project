"use client"

import type React from "react"
import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent } from "@/components/ui/card"
import { Plus, Pencil, Trash2, X, Upload } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { ProjectsDB } from "@/lib/db/storage"
import { cropImage } from "@/lib/utils/image-cropper"
import type { Project } from "@/lib/types"

export function ProjectsManager() {
  const [projects, setProjects] = useState<Project[]>([])
  const [isAdding, setIsAdding] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    image: "",
    link: "",
  })
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  useEffect(() => {
    loadProjects()
  }, [])

  const loadProjects = () => {
    setProjects(ProjectsDB.getAll())
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    try {
      const croppedImage = await cropImage(file)
      setFormData({ ...formData, image: croppedImage })

      toast({
        title: "Image uploaded",
        description: "Image has been cropped to 450x350",
      })
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to process image",
        variant: "destructive",
      })
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (editingId) {
      ProjectsDB.update(editingId, formData)
      setEditingId(null)
      toast({
        title: "Project updated",
        description: "Project has been updated successfully",
      })
    } else {
      ProjectsDB.create(formData)
      setIsAdding(false)
      toast({
        title: "Project added",
        description: "New project has been added successfully",
      })
    }

    setFormData({ title: "", description: "", image: "", link: "" })
    loadProjects()
  }

  const handleEdit = (project: Project) => {
    setFormData({
      title: project.title,
      description: project.description,
      image: project.image,
      link: project.link,
    })
    setEditingId(project.id)
    setIsAdding(false)
  }

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this project?")) {
      ProjectsDB.delete(id)
      loadProjects()
      toast({
        title: "Project deleted",
        description: "Project has been deleted successfully",
      })
    }
  }

  const handleCancel = () => {
    setIsAdding(false)
    setEditingId(null)
    setFormData({ title: "", description: "", image: "", link: "" })
  }

  return (
    <div className="space-y-6">
      {!isAdding && !editingId && (
        <Button onClick={() => setIsAdding(true)}>
          <Plus className="h-4 w-4 mr-2" />
          Add New Project
        </Button>
      )}

      {(isAdding || editingId) && (
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-bold text-slate-900">{editingId ? "Edit Project" : "Add New Project"}</h3>
              <Button variant="ghost" size="icon" onClick={handleCancel}>
                <X className="h-5 w-5" />
              </Button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-slate-900 mb-2">
                  Project Name
                </label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  required
                  placeholder="Project title"
                />
              </div>
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-slate-900 mb-2">
                  Project Description
                </label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  placeholder="Project description"
                  rows={3}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-slate-900 mb-2">Project Image</label>
                <div className="flex gap-2">
                  <Input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleImageUpload}
                    accept="image/*"
                    className="hidden"
                  />
                  <Button type="button" variant="outline" onClick={() => fileInputRef.current?.click()}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Image (450x350)
                  </Button>
                  <Input
                    value={formData.image}
                    onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                    placeholder="Or paste image URL"
                    className="flex-1"
                  />
                </div>
                {formData.image && (
                  <img
                    src={formData.image || "/placeholder.svg"}
                    alt="Preview"
                    className="mt-2 w-full max-w-md h-auto rounded-lg"
                  />
                )}
              </div>
              <div>
                <label htmlFor="link" className="block text-sm font-medium text-slate-900 mb-2">
                  Project Link
                </label>
                <Input
                  id="link"
                  value={formData.link}
                  onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                  required
                  placeholder="https://example.com"
                />
              </div>
              <div className="flex gap-2">
                <Button type="submit">{editingId ? "Update Project" : "Add Project"}</Button>
                <Button type="button" variant="outline" onClick={handleCancel}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <Card key={project.id}>
            <img src={project.image || "/placeholder.svg"} alt={project.title} className="w-full h-48 object-cover" />
            <CardContent className="p-4">
              <h3 className="text-xl font-bold text-slate-900 mb-2">{project.title}</h3>
              <p className="text-slate-600 mb-4 text-sm">{project.description}</p>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => handleEdit(project)}>
                  <Pencil className="h-4 w-4 mr-1" />
                  Edit
                </Button>
                <Button size="sm" variant="outline" onClick={() => handleDelete(project.id)}>
                  <Trash2 className="h-4 w-4 mr-1" />
                  Delete
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {projects.length === 0 && !isAdding && (
        <Card>
          <CardContent className="p-12 text-center">
            <p className="text-slate-600">No projects yet. Add your first project to get started.</p>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
