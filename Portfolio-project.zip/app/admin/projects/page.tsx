import { AuthGuard } from "@/components/admin/auth-guard"
import { DashboardLayout } from "@/components/admin/dashboard-layout"
import { ProjectsManager } from "@/components/admin/projects-manager"

export default function ProjectsPage() {
  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Projects</h1>
          <p className="text-slate-600">Manage your portfolio projects</p>
        </div>
        <ProjectsManager />
      </DashboardLayout>
    </AuthGuard>
  )
}
