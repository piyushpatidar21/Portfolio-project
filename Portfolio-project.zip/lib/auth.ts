export { AuthDB as auth } from "@/lib/db/storage"

// Export convenience functions for backward compatibility
export const isAuthenticated = () => {
  if (typeof window === "undefined") return false
  return localStorage.getItem("flipr_auth") === "authenticated"
}

export const logout = () => {
  localStorage.removeItem("flipr_auth")
}
