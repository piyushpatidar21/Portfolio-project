import type { DashboardStats } from "@/lib/types"
import { ProjectsDB, TestimonialsDB, ContactsDB, NewsletterDB } from "@/lib/db/storage"

export function getDashboardStats(): DashboardStats {
  return {
    totalProjects: ProjectsDB.getAll().length,
    totalTestimonials: TestimonialsDB.getAll().length,
    totalContacts: ContactsDB.getAll().length,
    totalSubscribers: NewsletterDB.getAll().length,
  }
}
