import { AuthGuard } from "@/components/admin/auth-guard"
import { DashboardLayout } from "@/components/admin/dashboard-layout"
import { NewsletterViewer } from "@/components/admin/newsletter-viewer"

export default function NewsletterPage() {
  return (
    <AuthGuard>
      <DashboardLayout>
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Newsletter Subscribers</h1>
          <p className="text-slate-600">Manage your newsletter subscription list</p>
        </div>
        <NewsletterViewer />
      </DashboardLayout>
    </AuthGuard>
  )
}
